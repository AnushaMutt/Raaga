export class User{
constructor(
public firstName ='',
public lastName ='',
public email ='',
public term ='',
public state = '',
public zip?:string)
{}


}
    
