import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from 'src/home/home.component';
import {MusicComponent} from 'src/music/music.component';
import { UserComponent } from "src/users/user.component";
import { AboutComponent } from "src/about/about.component";
import { PlayComponent } from "src/play/play.component";

const routes: Routes = [
{path:'home',component:HomeComponent},
  {path:'music',component:MusicComponent},
  {path:'about',component:AboutComponent},
 {path:'user',component:UserComponent},

  {path:'play',component:PlayComponent}

 // {path:'movies/:id',component:moviedetail}
  //{path:'',component:homeComponent},
  //{path:'**',component:HomeComponent,pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
