import { Component } from '@angular/core';


@Component({
  selector: 'music',
  templateUrl: './music.component.html',
  styleUrls: ['./music.component.css']
 

})

export class MusicComponent {
  router: any;
  songName: string;
  imgWidth:number;
  imgHeight:number;


songs:any[] = [
{songName: 'Hasi',singer:'Shreya',Image:"./assets/images/t1.jpg" },
{songName: 'ZaraZara',singer:'Jayshree',Image:"./assets/images/t2.jpg"  },
{songName: 'JaiHo',singer:'Vijay' ,Image:"./assets/images/t3.jpg"  }

];


  playMusic():void{
    this.songName="hindi";

  }
  onplay():void{
    this.router.navigate(['/play']);

  }

}










